package com.ibm.mobilefirstplatform.clientsdk.android.push;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest<ApplicationTestCase> extends ApplicationTestCase<ApplicationTestCase> {
    public ApplicationTest() {
        super(Application.class);
    }
}